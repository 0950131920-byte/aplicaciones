package com.aitec.edu.msprofesor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsprofesorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsprofesorApplication.class, args);
	}

}
