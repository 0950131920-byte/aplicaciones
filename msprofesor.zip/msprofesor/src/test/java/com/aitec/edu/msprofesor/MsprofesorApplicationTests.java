package com.aitec.edu.msprofesor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsprofesorApplicationTests {

	@Test
	void contextLoads() {
	}

}
